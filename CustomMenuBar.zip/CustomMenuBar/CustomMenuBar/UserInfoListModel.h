//
//  UserInfoListModel.h
//  SP2P_7
//
//  Created by Nancy on 2017/7/19.
//  Copyright © 2017年 EIMS. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfoListModel : NSObject
@property (nonatomic,assign)int infoId;
@property (nonatomic,copy)NSString *name;
@end
