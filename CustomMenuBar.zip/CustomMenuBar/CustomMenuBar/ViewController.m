//
//  ViewController.m
//  CustomMenuBar
//
//  Created by Nancy on 2017/8/15.
//  Copyright © 2017年 yq. All rights reserved.
//

#import "ViewController.h"
#import "BorrowDetailViewController.h"
#import "BorrowMoneyViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonAction:(id)sender {
    BorrowDetailViewController *info = [[BorrowDetailViewController alloc]init];
    info.skipTag=1;
    [self.navigationController pushViewController:info animated:YES];
    
}
- (IBAction)buttonAction2:(id)sender {
    BorrowMoneyViewController *borrowMoneyVC = [[BorrowMoneyViewController alloc]init];
    borrowMoneyVC.hidesBottomBarWhenPushed=YES;
    [self.navigationController pushViewController:borrowMoneyVC animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
