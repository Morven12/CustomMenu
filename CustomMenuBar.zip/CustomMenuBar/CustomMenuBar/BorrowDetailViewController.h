//
//  BorrowDetailViewController.h
//  SP2P_7
//
//  Created by Nancy on 2017/7/18.
//  Copyright © 2017年 EIMS. All rights reserved.
//

#import "ViewController.h"

@interface BorrowDetailViewController : ViewController
@property (nonatomic,assign) int skipTag;
@property (nonatomic,assign) int skipType;//3 ：从借款列表进入 // 4:没有申请过借款从首页进入
@end
