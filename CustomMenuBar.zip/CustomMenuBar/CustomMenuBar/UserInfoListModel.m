//
//  UserInfoListModel.m
//  SP2P_7
//
//  Created by Nancy on 2017/7/19.
//  Copyright © 2017年 EIMS. All rights reserved.
//

#import "UserInfoListModel.h"

@implementation UserInfoListModel
//-(id)initWithDictionary:(NSMutableDictionary*)dictionary{
//    if (self = [super init]) {
//        self.shortDate = [dictionary objectForKey:@"shortDate"];
//        self.lst =[dictionary objectForKey:@"lst"];
//    }
//    return self;
//}
@end
