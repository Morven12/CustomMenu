//
//  AppDelegate.h
//  CustomMenuBar
//
//  Created by Nancy on 2017/8/15.
//  Copyright © 2017年 yq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

