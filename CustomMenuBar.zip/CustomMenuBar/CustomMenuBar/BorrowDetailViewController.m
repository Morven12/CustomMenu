//
//  BorrowDetailViewController.m
//  SP2P_7
//
//  Created by Nancy on 2017/7/18.
//  Copyright © 2017年 EIMS. All rights reserved.
//

#import "BorrowDetailViewController.h"
#import "HWDownSelectedView.h"

#define KRedColor  SETCOLOR(205,40,44,1)//『去投资』背景红
@interface BorrowDetailViewController ()<HWDownSelectedViewDelegate,
//HTTPClientDelegate,
UITextFieldDelegate>{
    BOOL isHaveDian;
}



@property (weak, nonatomic) IBOutlet UITextField *moneyTextField;
@property (weak, nonatomic) IBOutlet HWDownSelectedView *deadlineBox;
@property (weak, nonatomic) IBOutlet UIButton *submitBtn;
@property (nonatomic,copy) NSString *periodiDateStr;
//@property(nonatomic ,strong) NetWorkClient *requestClient;
//@property (weak, nonatomic) IBOutlet BoomShowView *boomView;

@end

@implementation BorrowDetailViewController
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self.deadlineBox close];
    [self.moneyTextField resignFirstResponder];
}
-(void)leftBarButtonItemAction{
    if (self.skipTag == 1) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }else{
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)dealloc{
    self.periodiDateStr = @"";
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    
    self.navigationController.navigationBar.translucent=NO;
    
    self.title  = @"填写借款详情";
//    [self NavBackClick];
    [self createUI];
    
//    [self initView];
}



- (void)createUI{
    self.view.backgroundColor = [UIColor whiteColor];
    self.moneyTextField.keyboardType = UIKeyboardTypeDecimalPad;
    self.moneyTextField.delegate = self;
    self.submitBtn.layer.cornerRadius = 5.0f;
    self.submitBtn.layer.masksToBounds = YES;
    self.submitBtn.backgroundColor = [UIColor redColor];
    [self.submitBtn addTarget:self action:@selector(submitBorrowInfo) forControlEvents:UIControlEventTouchUpInside];
    
    self.deadlineBox.listArray = @[@"1个月",@"48天",@"3个月",@"6个月"];
    self.deadlineBox.delegate = self;
}

//#pragma mark- - 点击事件
- (void)submitBorrowInfo{

    [self.deadlineBox close];
    [self.moneyTextField resignFirstResponder];
    
    [self requestSubmitApplicationData];
    
}
- (void)requestSubmitApplicationData{
//    if (self.moneyTextField.text.length == 0) {
//        [SVProgressHUD showImage:nil status:@"请输入借款金额"];
//        return;
//    }
//    if (self.deadlineBox.text.length == 0 || self.periodiDateStr.length == 0) {
//        [SVProgressHUD showImage:nil status:@"请选择借款期限"];
//        return;
//    }
//    if (self.moneyTextField.text.floatValue < 200000) {
//        [SVProgressHUD showImage:nil status:@"借款金额不能超过20万"];
//        return;
//    }
    
//    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
//    [parameters setObject:OPT_236 forKey:@"OPT"];
//    [parameters setObject:@"" forKey:@"body"];
//    [parameters setObject:[NSString stringWithFormat:@"%@",AppDelegateInstance.userInfo.userId] forKey:@"userId"];
//    [parameters setObject:self.moneyTextField.text forKey:@"amount"];
//    [parameters setObject:self.periodiDateStr forKey:@"periodDate"];
//    if (_requestClient == nil) {
//        _requestClient = [[NetWorkClient alloc] init];
//        _requestClient.delegate = self;
//    }
//    DDLOG(@"提交 result=%@",parameters);
//    [_requestClient requestGet:BaseurlHeader withParameters:parameters];
//    //放借款标，集资，集资结束后放款，放款后押金退还，已经生成合同了
    //申请需要10%的押金
    //一个用户借款次数有限制么？在提交申请审核结果之前不能再提交了
}
#pragma HTTPClientDelegate 网络数据回调代理
//-(void) startRequest{
//    
//}
//-(void) httpResponseSuccess:(NetWorkClient *)client dataTask:(NSURLSessionDataTask *)task didSuccessWithObject:(id)obj{
//    
//    DDLOG(@"借款详情 请求result：%@",obj);
//    DDLOG(@"借款详情 请求result：%@",[obj objectForKey:@"msg"]);
//   
//    NSDictionary * dic = obj;
//    if ([[NSString stringWithFormat:@"%@",dic[@"error"]] isEqualToString:@"-1"]){
//        
//        [SVProgressHUD showSuccessWithStatus:@"借款申请提交成功"];
//        //提交完整信息
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            [self.navigationController popToRootViewControllerAnimated:YES];
//        });
//    } else {
//        [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"%@", [obj objectForKey:@"msg"]]];
//         /*error:用户名或者密码错误,必须在恒丰账户下操作*/
//    }
//}
//-(void) httpResponseFailure:(NetWorkClient *)client dataTask:(NSURLSessionDataTask *)task didFailWithError:(NSError *)error{
//    [SVProgressHUD showErrorWithStatus:[NSString stringWithFormat:@"%@", @"借款申请提交失败"]];
//}
//-(void) networkError{
//    [SVProgressHUD showErrorWithStatus:@"请检查一下网络"];
//}


#pragma mark - HWDownSelectedViewDelegate
- (void)downSelectedView:(HWDownSelectedView *)selectedView didSelectedAtIndex:(NSIndexPath *)indexPath{
    
    [self.moneyTextField resignFirstResponder];
    if (indexPath.row == 0) {
        self.periodiDateStr = @"30";
    }else if (indexPath.row == 1){
        self.periodiDateStr = @"48";
    }else if (indexPath.row == 2){
        self.periodiDateStr = @"90";
    }else{
        self.periodiDateStr = @"180";
    }
}
#pragma mark - textfiele长度
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSString *beString=[textField.text stringByReplacingCharactersInRange:range withString:string];
    if ([beString length] > 10) {
        textField.text = [beString substringToIndex:10];
        return NO;
    }
    return YES;
}

/*
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if ((textField.tag == 1000) || (textField.tag == 1003)) {
        if ([textField.text rangeOfString:@"."].location==NSNotFound) {
            isHaveDian=NO;
        }
        if ([string length]>0){
            unichar single=[string characterAtIndex:0];//当前输入的字符
            if ((single >='0' && single<='9') || single=='.')//数据格式正确
            {
                //首字母不能为0和小数点
                if([textField.text length]==0){
                    if(single == '.'){
                        if (textField.tag == 1000) {
                            [self.topupView.topUpbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }else{
                            [self.withdrawalView.withdrawalbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }
                        return NO;
                        
                    }
                    if (single == '0') {
                        if (textField.tag == 1000) {
                            [self.topupView.topUpbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }else{
                            [self.withdrawalView.withdrawalbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }
                        return NO;
                    }
                }
                if (single=='.')
                {
                    if(!isHaveDian)//text中还没有小数点
                    {
                        isHaveDian=YES;
                        return YES;
                    }else
                    {
                        if (textField.tag == 1000) {
                            [self.topupView.topUpbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }else{
                            [self.withdrawalView.withdrawalbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                        }
                        return NO;
                    }
                }else{
                    //存在小数点
                    if (isHaveDian)
                    {
                        if (textField.tag == 1000) {
                            //判断小数点的位数
                            NSRange ran=[self.topupView.topUpbottonView.moneyTextField.text rangeOfString:@"."];
                            NSInteger tt=range.location-ran.location;
                            if (tt <= 2){
                                return YES;
                            }else{
                                return NO;
                            }
                        }else{//1003
                            //判断小数点的位数
                            NSRange ran=[self.withdrawalView.withdrawalbottonView.moneyTextField.text rangeOfString:@"."];
                            NSInteger tt=range.location-ran.location;
                            if (tt <= 2){
                                return YES;
                            }else{
                                return NO;
                            }
                        }
                    }else{
                        return YES;
                    }
                }
            }else{//输入的数据格式不正确
                if (textField.tag == 1000) {
                    [self.topupView.topUpbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                }else{
                    [self.withdrawalView.withdrawalbottonView.moneyTextField.text stringByReplacingCharactersInRange:range withString:@""];
                }
                return NO;
            }
        }else{
            return YES;
        }
    }else{
        return YES;
    }
}*/
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
